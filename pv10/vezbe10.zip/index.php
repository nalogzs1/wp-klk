<!-- TODO 6 - Inicijalizacija -->

<html>
<head>
    <title>Player score</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <form class="container">
        <!-- TODO 1 -->
    </form>
    <div class="container">
        <h5>Previously loaded files:</h5>
        <!-- TODO 6 - Ispis -->
    </div>
</body>
</html>