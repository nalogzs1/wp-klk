<?php 
    require_once("classes/Score.php");

    function parse($filename) {
        //TODO 3
    }

    function append($filename, $new_score){
        //TODO 3
    }

?>