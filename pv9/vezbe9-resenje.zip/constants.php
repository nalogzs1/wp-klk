<?php

    define("TBL_USER", "User");
    define("COL_USER_USERNAME", "username");
    define("COL_USER_ID", "id");
    define("COL_USER_PASSWORD", "password");
    define("COL_USER_NAME", "name");
    define("COL_USER_AVATAR", "avatar");
    define("COL_USER_PROFESSION", "profession");
    define("COL_USER_ADDRESS", "address");
    define("COL_USER_BIRTHDAY", "birthday");
    define("COL_USER_GENDER", "gender");

    define("TBL_POST", "Post");
    define("COL_POST_TIME", "time");
    define("COL_POST_ID", "id");
    define("COL_POST_CONTENT", "content");
    define("COL_POST_USERID", "userId");