<?php 
include
require
include_once
require_once


require_once "classes/Klasa.php";
require_once "parts.php";
pageHeader(...);


pageFoote(....);

?>