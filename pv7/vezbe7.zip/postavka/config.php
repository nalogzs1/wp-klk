<?php
	define("DB_NAME", "cinema.db");
	define("TBL_MOVIE", "Film");
	define("COL_MOVIE_ID", "id");
	define("COL_MOVIE_NAME", "naziv");
	define("TBL_RESERVATION", "Rezervacija");
	define("COL_RES_MOVIE", "film");
	define("COL_RES_SEAT", "sediste");
	define("COL_RES_NAME", "ime");
	define("COL_RES_PHONE", "telefon");
	define("COL_RES_EMAIL", "email");
?>