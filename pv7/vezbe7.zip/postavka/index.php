<?php
    require_once("DBUtils.php");

    DBUtils::initDB();

?>
<html>
<head>
    <title>Bioskop</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Spectral+SC" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
	<h1>Repertoar bioskopa</h1>
	<div class="movies">
		<!-- 
		TODO: 
		Dobaviti i ispisati sve filmove. 
		Ako je korisnik kliknuo na neki film, prikazati matricu raspolozivih mesta za taj film.
		-->
	</div>
</body>
</html>
